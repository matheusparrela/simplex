# Pesquisa Operacional
## Método Simplex
