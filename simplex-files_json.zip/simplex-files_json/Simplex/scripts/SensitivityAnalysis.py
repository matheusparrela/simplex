import numpy as np


class SensitivityAnalysis:

    def __init__(self, problem):
        self.problem = problem

    def analysis(self):
        pass
